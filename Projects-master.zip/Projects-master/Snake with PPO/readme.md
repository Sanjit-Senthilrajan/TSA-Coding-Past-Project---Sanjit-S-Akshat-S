# About
Author: Keshav
This program trains an agent to play the classic game of snake using the reinforcement learning algorithim PPO. You can also play the game manually if you'd like.

# Demo
Check out a demo on the Ascent youtube channel (not out yet)