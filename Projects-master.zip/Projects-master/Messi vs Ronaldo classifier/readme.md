# About
Author: Keshav
I created a simple CNN trained on a dataset of pictures of Messi and Ronaldo. 

# Demo
Check out a demo on the Ascent youtube channel 
https://www.youtube.com/watch?v=sagmKy3o83w&t=40s