# About
Author: Keshav
I trained a yolo model on a dataset of minecraft ores

# Demo
Check out a demo on the Ascent youtube channel 
https://www.youtube.com/shorts/T4XdU_YAnqA