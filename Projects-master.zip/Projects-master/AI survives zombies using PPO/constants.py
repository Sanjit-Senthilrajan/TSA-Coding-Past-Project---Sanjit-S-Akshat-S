SIZE = 40
WIDTH, HEIGHT = 1000, 1000
PLAYER_SPEED = 6
ZOMBIE_SPEED = 3

MAX_STEPS = 2000
total_timesteps = 3_000_000
eval_interval = 100_000
episodes_per_eval = 5
