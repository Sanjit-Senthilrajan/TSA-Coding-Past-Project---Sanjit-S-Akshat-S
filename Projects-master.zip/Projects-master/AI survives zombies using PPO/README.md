# AI survives Zombies using PPO
Author: Keshav
This project uses Proximal Policy Optimization, a renforcement learning algorthim, to train an AI agent to escape zombies.

# Demo
Check out a full demo on the Ascent youtube channel, which you can access below:
https://www.youtube.com/watch?v=eJgHia54Yrg&t=102s