# About
Author: Keshav
I created a simple FNN trained on the MNIST dataset. 

# Demo
Check out a demo on the Ascent youtube channel 
https://www.youtube.com/shorts/euByd75YPco