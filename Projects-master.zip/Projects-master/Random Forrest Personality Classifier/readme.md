# About
Author: Keshav
I created a simple Random Forrest model trained on a synthetic dataset. 

# Demo
Check out a demo on the Ascent youtube channel 
https://www.youtube.com/shorts/JWsB9lWFGdc