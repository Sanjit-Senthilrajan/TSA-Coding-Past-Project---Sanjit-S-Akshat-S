# Ascent-Projects
All the projects covered on the Ascent social media platform. Check them out here:
- 🔴 [YouTube (@ascent2)](https://www.youtube.com/@ascent2)  
- 📸 [Instagram (@ascent100)](https://www.instagram.com/ascent100)  
- 🎵 [TikTok (@ascent513)](https://www.tiktok.com/@ascent513)
