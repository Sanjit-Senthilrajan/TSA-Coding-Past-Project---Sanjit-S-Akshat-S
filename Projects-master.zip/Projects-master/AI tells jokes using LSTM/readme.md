# About
Author: Keshav
I created an LSTM model trained on a dataset of jokes. It is not very accurate but somewhat works?

# Demo
Check out a demo on the Ascent youtube channel 
https://www.youtube.com/shorts/QrgkLXUs2Fo 